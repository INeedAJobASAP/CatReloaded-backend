using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Data.OleDb;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace login_register_system
{
    public partial class frmRegister : Form
    {
        public frmRegister()
        {
            InitializeComponent();
        }
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=db_users.mdb;");
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataAdapter da = new OleDbDataAdapter();

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkbxShowPas.Checked)
            {
                txtpassword.PasswordChar = '\0';
                txtComPassword.PasswordChar = '\0';
            }
            else
            {
                txtpassword.PasswordChar = '*';
                txtComPassword.PasswordChar = '*';
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtusername.Text) || string.IsNullOrWhiteSpace(txtpassword.Text) ||
                string.IsNullOrWhiteSpace(txtComPassword.Text) || string.IsNullOrWhiteSpace(txtemail.Text))
            {
                MessageBox.Show("Username, Email, or Password fields are empty", "Registration Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (txtpassword.Text != txtComPassword.Text)
            {
                MessageBox.Show("Passwords do not match, please re-enter your password.", "Registration Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtpassword.Text = "";
                txtComPassword.Text = "";
                txtpassword.Focus();
                return;
            }


            if (!isemail(txtemail.Text))
            {
                MessageBox.Show("Invalid email format. Please enter a valid email.", "Registration Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtemail.Focus();
                return;
            }
            try
            {

                con.Open();


                string registerQuery = "INSERT INTO tbl_users VALUES ('" +
                                       txtusername.Text + "', '" +
                                       HashPassword(txtpassword.Text) + "', '" +
                                       txtemail.Text + "')";


                OleDbCommand cmd = new OleDbCommand(registerQuery, con);
                cmd.ExecuteNonQuery();


                con.Close();
                txtusername.Text = "";
                txtpassword.Text = "";
                txtComPassword.Text = "";
                txtemail.Text = "";


                MessageBox.Show("Your account has been successfully created!", "Registration Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error: " + ex.Message, "Registration Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
            

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtusername.Text = "";
            txtpassword.Text = "";
            txtComPassword.Text = "";
            txtemail.Text = "";
            txtusername.Focus();
        }

        private void label6_Click_1(object sender, EventArgs e)
        {
            new frmLogin().Show();
            this.Hide();
        }
        private bool isemail(string email)
        {
            try
            {
                var mailAddress = new System.Net.Mail.MailAddress(email);
                return true;
            }
            catch
            {
                return false;
            }
        }
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}